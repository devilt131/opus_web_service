import { createRouter, createWebHistory } from 'vue-router'
import Analyzer from '../components/Analyzer.vue'
import History from '../components/History.vue'
import Profile from '../components/Profile.vue'

const routes = [
  {
    path: '/',
    name: 'Analyzer',
    component: Analyzer
  },
  {
    path: '/history',
    name: 'History',
    component: History
  },
  {
    path: '/profile',
    name: 'Profile',
    component: Profile
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default routes