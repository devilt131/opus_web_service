<template>
  <div class="analyze">
    <h1>Text Analysis</h1>

    <div class="drop-zone" @dragover.prevent @drop.prevent="handleDrop">
      <p>Drop file here or <button @click="openFile">browse</button></p>
      <input ref="fileInput" type="file" @change="handleFile" style="display:none" accept=".txt,.pdf,.docx" />
    </div>

    <textarea v-model="text" rows="10" placeholder="Paste text here..."></textarea>
    
    <div class="action-bar">
      <span>{{ text.length }} characters</span>
      <button @click="analyze" :disabled="loading">{{ loading ? 'Analyzing...' : 'Analyze' }}</button>
    </div>

    <div v-if="loading" class="loader"></div>

    <div v-if="result" class="results">
      <div class="card">
        <h3>Title</h3>
        <p>{{ result.title }}</p>
      </div>

      <div class="card">
        <h3>Summary</h3>
        <p>{{ result.summary }}</p>
        <div class="badge">Compressed {{ result.compression }}%</div>
      </div>

      <div class="card">
        <h3>Plan</h3>
        <div class="plan" v-html="formattedPlan"></div>
      </div>

      <div class="card">
        <h3>Keywords</h3>
        <div class="tags">
          <span v-for="k in result.keywords" :key="k.word" class="tag">{{ k.word }} ({{ k.freq }})</span>
        </div>
      </div>

      <div class="card">
        <h3>Statistics</h3>
        <div>Characters: {{ result.stats.chars }}</div>
        <div>Words: {{ result.stats.words }}</div>
        <div>Sentences: {{ result.stats.sentences }}</div>
        <div>Unique: {{ result.stats.unique }}</div>
      </div>

      <div class="card">
        <h3>Named Entities</h3>
        <div><strong>Persons:</strong> {{ entities.persons.map(e => e.text).join(', ') }}</div>
        <div><strong>Organizations:</strong> {{ entities.orgs.map(e => e.text).join(', ') }}</div>
        <div><strong>Locations:</strong> {{ entities.locs.map(e => e.text).join(', ') }}</div>
        <div><strong>Dates:</strong> {{ entities.dates.map(e => e.text).join(', ') }}</div>
      </div>

      <div class="card" v-if="hasPlagiarism">
        <h3>Plagiarism Check</h3>
        <div>Uniqueness: {{ result.plagiarism.uniqueness }}%</div>
        <div>Similarity: {{ result.plagiarism.similarity }}</div>
        <div>Common words: {{ result.plagiarism.common.join(', ') }}</div>
      </div>

      <div class="export-bar">
        <button @click="exportTxt">TXT</button>
        <button @click="exportJson">JSON</button>
        <button @click="exportPdf">PDF</button>
      </div>
    </div>

    <div v-if="error" class="error">{{ error }}</div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      text: '',
      loading: false,
      result: null,
      error: ''
    }
  },
  computed: {
    formattedPlan() {
      if (!this.result?.plan) return ''
      return this.result.plan.replace(/\n/g, '<br>')
    },
    entities() {
      return this.result?.entities || { persons: [], orgs: [], locs: [], dates: [] }
    },
    hasPlagiarism() {
      return this.result?.plagiarism && this.result.plagiarism.uniqueness
    }
  },
  methods: {
    openFile() {
      this.$refs.fileInput.click()
    },
    async handleFile(e) {
      const file = e.target.files[0]
      const form = new FormData()
      form.append('file', file)
      this.loading = true
      try {
        const res = await axios.post('http://localhost:8000/upload', form)
        this.result = res.data
      } catch (err) {
        this.error = 'upload failed'
      } finally {
        this.loading = false
      }
    },
    async handleDrop(e) {
      const file = e.dataTransfer.files[0]
      const form = new FormData()
      form.append('file', file)
      this.loading = true
      try {
        const res = await axios.post('http://localhost:8000/upload', form)
        this.result = res.data
      } catch (err) {
        this.error = 'upload failed'
      } finally {
        this.loading = false
      }
    },
    async analyze() {
      if (!this.text.trim()) return
      this.loading = true
      this.error = ''
      try {
        const res = await axios.post('http://localhost:8000/analyze', { text: this.text })
        this.result = res.data
      } catch (err) {
        this.error = 'analysis failed'
      } finally {
        this.loading = false
      }
    },
    async exportTxt() {
      const res = await axios.post('http://localhost:8000/export/txt', { text: this.text }, { responseType: 'blob' })
      const url = URL.createObjectURL(res.data)
      const a = document.createElement('a')
      a.href = url
      a.download = 'opus_report.txt'
      a.click()
      URL.revokeObjectURL(url)
    },
    async exportJson() {
      const res = await axios.post('http://localhost:8000/export/json', { text: this.text }, { responseType: 'blob' })
      const url = URL.createObjectURL(res.data)
      const a = document.createElement('a')
      a.href = url
      a.download = 'opus_report.json'
      a.click()
      URL.revokeObjectURL(url)
    },
    async exportPdf() {
      const res = await axios.post('http://localhost:8000/export/pdf', { text: this.text }, { responseType: 'blob' })
      const url = URL.createObjectURL(res.data)
      const a = document.createElement('a')
      a.href = url
      a.download = 'opus_report.pdf'
      a.click()
      URL.revokeObjectURL(url)
    }
  }
}
</script>

<style scoped>
.analyze { max-width: 900px; margin: 0 auto; }
textarea { width: 100%; padding: 10px; background: #111; color: #fff; border: 1px solid #333; border-radius: 6px; }
button { margin-top: 10px; padding: 8px 20px; background: #1e6f9f; color: white; border: none; border-radius: 6px; cursor: pointer; }
.drop-zone { border: 2px dashed #333; padding: 20px; text-align: center; margin-bottom: 20px; border-radius: 8px; }
.loader { width: 30px; height: 30px; border: 2px solid #333; border-top-color: #1e6f9f; border-radius: 50%; animation: spin 1s linear infinite; margin: 20px auto; }
@keyframes spin { to { transform: rotate(360deg); } }
.results { margin-top: 20px; display: flex; flex-direction: column; gap: 16px; }
.card { background: #111; border: 1px solid #222; border-radius: 8px; padding: 16px; }
.card h3 { margin-top: 0; color: #1e6f9f; }
.tags { display: flex; flex-wrap: wrap; gap: 8px; }
.tag { background: #1a1a1a; padding: 4px 10px; border-radius: 16px; font-size: 13px; }
.badge { display: inline-block; background: #1a1a1a; padding: 2px 8px; border-radius: 4px; font-size: 11px; margin-top: 8px; }
.plan { white-space: pre-wrap; line-height: 1.5; }
.export-bar { display: flex; gap: 10px; margin-top: 10px; }
.error { color: red; margin-top: 10px; }
.action-bar { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; }
</style>